GRBL-Arduino-Library
====================

Arduino Library for GRBL - This way you can use the Arduino IDE to upload GRBL to your Arduino Board.


How to install it:
==================

- Down load the library from GitHub : https://github.com/Protoneer/GRBL-Arduino-Library/archive/master.zip

- Unzip the library and copy the main folder into the “Libraries” folder in the folder you installed your Arduino software. Eg. C:\arduino-1.0.3\libraries\

- Rename the folder to “GRBL”. (This will stop the Arduino IDE from complaining about the long folder name)

- Open up the Arduino IDE.

- Click on the following menu : File -> Examples – > GRBL (or what ever you renamed the folder to) -> ArduinoUno

- Upload the sketch to your Arduino board.
